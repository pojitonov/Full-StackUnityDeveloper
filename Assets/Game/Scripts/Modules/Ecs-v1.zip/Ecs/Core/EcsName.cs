using System;

namespace Leopotam.EcsLite
{
    [Serializable]
    public struct EcsName
    {
        public string value;
    }
}