namespace Leopotam.EcsLite
{
    public interface IEcsEntityInstaller
    {
        void Install(EcsWorld world, int entity);
    }
}