namespace Leopotam.EcsLite
{
    public struct EcsActive
    {
    }
}